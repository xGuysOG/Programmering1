package mouseclicked;

import javafx.application.Application;

public class MouseClickedApp {

    public static void main(String[] args) {
        Application.launch(MouseClickedGui.class);
    }
}
