package model;

public enum SeatType {
    STANDARD,
    LONGLEGS,
    WHEELCHAIR
}
