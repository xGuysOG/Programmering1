package model;

public enum Varekategori {
    STUDIEBOG,
    MOBILTELEFON,
    COMPUTER,
    TØJ,
    ANDET
}
